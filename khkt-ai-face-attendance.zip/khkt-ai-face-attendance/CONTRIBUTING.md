
# Quy tắc đóng góp
- Tạo nhánh theo định dạng: `feature/<mota-ngan>`
- Dùng commit message kiểu Conventional Commits
- Viết test tối thiểu cho module mới
