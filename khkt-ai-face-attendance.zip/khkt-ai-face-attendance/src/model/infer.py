
import pickle, os
import numpy as np
import face_recognition

EMB_PATH = os.path.join(os.path.dirname(__file__), "../../models/embeddings.pkl")

def load_embeddings():
    with open(EMB_PATH, "rb") as f:
        data = pickle.load(f)
    return data["embeddings"], data["names"]

def predict(image_np):
    embeddings, names_map = load_embeddings()
    boxes = face_recognition.face_locations(image_np, model="hog")
    encs = face_recognition.face_encodings(image_np, boxes)
    results = []
    for enc in encs:
        matches = face_recognition.compare_faces(embeddings, enc, tolerance=0.5)
        name = "Unknown"
        if True in matches:
            idx = matches.index(True)
            for n, i in names_map.items():
                if i == idx:
                    name = n
                    break
        results.append(name)
    return results
