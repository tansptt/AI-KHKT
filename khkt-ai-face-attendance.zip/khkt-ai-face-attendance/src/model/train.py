
import os, glob, pickle
import numpy as np
import face_recognition
from pathlib import Path

RAW = Path(__file__).resolve().parents[2] / "data" / "raw"
OUT = Path(__file__).resolve().parents[2] / "models"
OUT.mkdir(parents=True, exist_ok=True)

embeddings = []
names_map = {}

idx = 0
for person_dir in RAW.glob("*/*"):
    if person_dir.is_dir():
        name = person_dir.name
        for img_path in glob.glob(str(person_dir / "*.jpg")) + glob.glob(str(person_dir / "*.png")):
            image = face_recognition.load_image_file(img_path)
            boxes = face_recognition.face_locations(image, model="hog")
            encs = face_recognition.face_encodings(image, boxes)
            if len(encs) == 0:
                continue
            embeddings.append(encs[0])
            names_map[name] = idx
            idx += 1

with open(OUT / "embeddings.pkl", "wb") as f:
    pickle.dump({"embeddings": embeddings, "names": names_map}, f)

print(f"Saved embeddings: {len(embeddings)} vectors for {len(names_map)} identities.")
