def hello():
    return 'utils ready'
