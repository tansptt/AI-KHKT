
from fastapi import FastAPI, UploadFile, File
from pydantic import BaseModel
from typing import List, Optional
import io
import numpy as np
from PIL import Image
import face_recognition
import sqlite3, os, pickle, datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "../../attendance.sqlite3")
EMB_PATH = os.path.join(os.path.dirname(__file__), "../../models/embeddings.pkl")

app = FastAPI(title="KHKT Face Attendance API", version="0.1.0")

def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("CREATE TABLE IF NOT EXISTS attendance (name TEXT, time TEXT, class TEXT)")
    return conn

def load_embeddings():
    if not os.path.exists(EMB_PATH):
        return {}, []
    with open(EMB_PATH, "rb") as f:
        data = pickle.load(f)
    return data.get("names", {}), data.get("embeddings", [])

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/attendance/verify")
async def verify(class_name: Optional[str] = None, file: UploadFile = File(...)):
    # read image
    content = await file.read()
    image = np.array(Image.open(io.BytesIO(content)).convert("RGB"))
    # face encodings
    boxes = face_recognition.face_locations(image, model="hog")
    encs = face_recognition.face_encodings(image, boxes)
    names_map, embeddings = load_embeddings()

    recognized = []
    for enc in encs:
        matches = face_recognition.compare_faces(embeddings, enc, tolerance=0.5)
        name = "Unknown"
        if True in matches:
            idx = matches.index(True)
            # find name by index
            for n, i in names_map.items():
                if i == idx:
                    name = n
                    break
        recognized.append(name)

    # write attendance
    conn = get_conn()
    for n in recognized:
        if n != "Unknown":
            conn.execute("INSERT INTO attendance VALUES (?,?,?)", (n, datetime.datetime.now().isoformat(), class_name or ""))
    conn.commit()
    conn.close()

    return {"recognized": recognized, "count": len(recognized)}
