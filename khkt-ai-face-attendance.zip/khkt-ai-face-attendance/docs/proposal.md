
# Đề cương KHKT — Điểm danh học sinh bằng nhận diện khuôn mặt

## 1. Vấn đề nghiên cứu
- Thực trạng điểm danh thủ công gây tốn thời gian, dễ sai sót/gian lận.
- Câu hỏi: AI có thể giảm thời gian điểm danh xuống < 10 giây/lớp và chính xác > 95%?

## 2. Giả thuyết
- Sử dụng học sâu/nhúng khuôn mặt sẽ nhận dạng tốt trong điều kiện lớp học thông thường.

## 3. Mục tiêu
- Hệ thống demo có API và database lưu chuyên cần.
- Đánh giá độ chính xác theo ánh sáng/góc mặt/khoảng cách.

## 4. Phương pháp
- Thu thập dữ liệu ảnh có sự đồng thuận.
- Tiền xử lý, trích xuất embedding, so khớp gần nhất.
- Thực nghiệm A/B với các tham số (tolerance, số ảnh/người).

## 5. Kế hoạch & mốc thời gian
- Tuần 1–2: Thu dữ liệu & tiền xử lý
- Tuần 3–4: Huấn luyện & thử nghiệm
- Tuần 5: Tích hợp API & báo cáo

## 6. Rủi ro & đạo đức
- Quyền riêng tư: xin phép, lưu mã hoá, cho phép xoá dữ liệu theo yêu cầu.
- Sai số nhận dạng: luôn có nút xác nhận thủ công.

## 7. Kết quả kỳ vọng
- Demo hoạt động ổn định, số liệu thống kê minh bạch, mã nguồn mở.
