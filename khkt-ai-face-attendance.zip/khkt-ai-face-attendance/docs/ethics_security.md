
# An toàn, đạo đức & bảo mật dữ liệu
- Thu thập dữ liệu có sự đồng ý của học sinh/phụ huynh.
- Ẩn danh hoá/ghi danh bằng mã ID thay tên thật nếu cần.
- Lưu mô hình/embedding cục bộ; không gửi ảnh lên máy chủ bên thứ ba.
- Quy trình xoá dữ liệu theo yêu cầu.
- Đánh giá định kỳ sai số và thiên lệch.
