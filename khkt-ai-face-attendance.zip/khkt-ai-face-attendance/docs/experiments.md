
# Thiết kế thí nghiệm & tiêu chí đánh giá
- Precision/Recall, Accuracy
- Stress test: ánh sáng yếu/mạnh, đeo khẩu trang/kính, quay đầu ±30°
- Bảng ghi chép thí nghiệm ở `docs/results_report.md`
