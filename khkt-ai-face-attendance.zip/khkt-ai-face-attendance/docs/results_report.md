# Kết quả & báo cáo thí nghiệm

> Điền bảng kết quả, chèn hình biểu đồ, phân tích hạn chế.
