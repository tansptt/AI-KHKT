
# Kiến trúc hệ thống

```mermaid
flowchart LR
A[Camera/Webcam] --> B[API FastAPI]
B --> C[Face Detection + Embedding]
C --> D[(Vector DB - pickle)]
B --> E[(SQLite Attendance)]
B --> F[Dashboard/Client]
```
