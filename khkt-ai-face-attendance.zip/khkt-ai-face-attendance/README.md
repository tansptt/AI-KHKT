
# KHKT — Ứng dụng Điểm Danh Học Sinh bằng Nhận Diện Khuôn Mặt (Template)

> **Mục tiêu:** Đây là repo mẫu (template) cho dự án KHKT THPT lĩnh vực Tin học. Repo cung cấp sẵn cấu trúc, tài liệu, mã nguồn tối thiểu, kiểm thử, CI và hướng dẫn triển khai để bạn có thể **fork/clone** và phát triển nhanh đề tài nhận diện khuôn mặt (hoặc thay thế bằng bài toán AI khác).

## 1) Tính mới & Ý nghĩa
- Tự động hóa điểm danh, giảm thời gian đầu giờ, hạn chế gian lận.
- Tích hợp quản lý đi học/đến muộn, xuất báo cáo cho GVCN & nhà trường.
- Mở rộng: chấm công CLB/đoàn đội, ra/vào thư viện, kiểm soát vào cổng.

## 2) Yêu cầu tối thiểu
- Python 3.10+
- Camera/laptop webcam
- GPU (tùy chọn) — CPU vẫn chạy được bản demo
- Hệ điều hành: Windows/Linux/macOS

## 3) Cài đặt nhanh
```bash
# 1) Tạo môi trường
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Cài thư viện
pip install -U pip
pip install -r requirements.txt

# 3) Chạy API demo (FastAPI)
uvicorn src.api.app:app --reload

# 4) Mở docs
# Truy cập http://127.0.0.1:8000/docs
```

## 4) Thư mục chính
```
src/
  api/        # FastAPI endpoints (điểm danh, quản lý lớp)
  model/      # Huấn luyện & suy luận (face recognition)
  utils/      # Hàm tiện ích (đọc ảnh, lưu dữ liệu,...)
data/
  raw/        # Dữ liệu gốc (ảnh chụp học sinh)
  processed/  # Dữ liệu đã xử lý
notebooks/    # Notebook minh họa tiền xử lý / huấn luyện
docs/         # Hồ sơ KHKT: đề cương, sơ đồ hệ thống, đánh giá rủi ro/đạo đức
tests/        # Kiểm thử đơn vị
```

## 5) Cách dùng nhanh (demo)
1. Chụp 5–10 ảnh khuôn mặt cho mỗi học sinh vào `data/raw/<lop>/<hoten>/...jpg`
2. Chạy `python src/model/train.py` để trích đặc trưng & lưu `models/embeddings.pkl`
3. Chạy API `uvicorn src.api.app:app --reload`
4. Gọi endpoint `/attendance/verify` với ảnh để nhận thông tin nhận dạng.

## 6) KHKT – Bộ tài liệu nộp
- `docs/proposal.md`: Đề cương dự án (mục tiêu, giả thuyết, phương pháp)
- `docs/system-architecture.md`: Kiến trúc hệ thống + lưu đồ
- `docs/ethics_security.md`: An toàn, đạo đức, quyền riêng tư (GDPR cơ bản)
- `docs/experiments.md`: Thiết kế thí nghiệm & tiêu chí đánh giá
- `docs/results_report.md`: Kết quả, bảng biểu, hạn chế, hướng phát triển

## 7) Công nghệ chính
- **Face detection:** `opencv-python`, `mediapipe` (hoặc `mtcnn`)
- **Face embedding:** `face_recognition`/`dlib` (CPU) hoặc `insightface` (GPU)
- **API:** `fastapi`, `pydantic`, `uvicorn`
- **Lưu trữ:** `sqlite3` (demo) → có thể nâng cấp PostgreSQL
- **CI:** GitHub Actions — kiểm lỗi & chạy test cơ bản

## 8) Hướng dẫn chấm thi
- Có video demo sử dụng thật trong lớp học.
- Báo cáo so sánh độ chính xác với nhiều điều kiện ánh sáng/góc mặt.
- Bảng nhật ký nghiên cứu (timeline) + nhật ký commit Git.
- Phân tích rủi ro đạo đức & phương án giảm thiểu (mã hóa/ẩn danh).
- Kế hoạch mở rộng: thống kê chuyên cần, Dashboard PowerBI/Grafana.

> Bạn có thể đổi bài toán (phân loại rác, nhận dạng chữ viết, v.v.) nhưng vẫn giữ **khung repo** này.
